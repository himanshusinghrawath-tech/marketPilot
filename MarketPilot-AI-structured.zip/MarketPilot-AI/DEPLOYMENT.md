# MarketPilot AI — Deployment Notes

## Project layout
- `src/`: React + Vite frontend
- `backend/`: FastAPI Python API
- `package.json`: frontend scripts/dependencies
- `requirements.txt`: Python backend dependencies
- `.env.example`: environment-variable template (no secrets)

## Run locally
1. Install Node.js (compatible with your Vite version) and Python.
2. From the project root, run `npm install`.
3. Create a local `.env` using `.env.example` as a reference and add secrets locally only.
4. Start the API in one terminal: `python -m uvicorn backend.main:app --reload --port 8000`
5. Start the frontend in another terminal: `npm run dev`
6. Open the local URL printed by Vite.

## Deployment notes
The frontend and FastAPI backend are separate deployable parts. Vercel can host the Vite frontend, but the Python API needs its own compatible deployment setup or hosting service unless converted/configured for serverless functions. Set the frontend API base URL to the deployed backend URL using a Vite environment variable (for example `VITE_API_BASE_URL`) and configure CORS on the backend to allow the deployed frontend origin.

Do not commit `.env`, API keys, local user data, `node_modules`, `dist`, or Python cache files. Rotate any API key if it was ever committed publicly.
